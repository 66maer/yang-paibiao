This folder contains the schema of the configuration model for the API services
platform.

**Note**: Protos under this directory are in Alpha status, and therefore are
subject to breaking changes.
